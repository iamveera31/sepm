<?php
	$con=mysqli_connect('localhost','root','','cricbuzz');
	if($con==false)
	{
		echo "connection is not done";
	}
	else
	{
		
	}


?>

